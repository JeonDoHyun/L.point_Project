##서울 미세먼지 데이터
seoul <- read.csv("original_air_seoul.csv", header=TRUE)  #엑셀로 전처리한 데이터
air_seoul <- seoul[,-c(1:4)]

##미세먼지와 클렌징, 스킨케어, 선케어, 헤어케어, 마스크/팩 데이터랩 검색량 합치기
d_cleansing <- read.csv("datalap_cleansing.csv", header=TRUE)
d_skincare <- read.csv("datalap_skincare.csv", header=TRUE)
d_suncare <- read.csv("datalap_suncare.csv", header=TRUE)
d_haircare <- read.csv("datalap_haircare.csv", header=TRUE)
d_maskpack <- read.csv("datalap_mask.csv", header=TRUE)
air_datalap <- data.frame(air_seoul[,c(1,4,5)],d_cleansing$CLEANSING, d_skincare$SKINCARE, d_suncare$SUNCARE, 
                          d_haircare$HAIRCARE, d_maskpack$MASK_PACK)

##엘포인트 데이터 추출 - 헤어케어, 선케어, 클렌저
personalcare <- read.csv("personalcare.csv", header=TRUE)
cosmetic <- read.csv("cosmetic.csv", header=TRUE)
sub_personal <- personalcare[,c(1,7,9)]
sub_cosmetic <- cosmetic[,c(1,7,8,9)]
cleanser <- sub_cosmetic[grep("페이셜클렌저", sub_cosmetic$CLAC3_NM),]
hair <- sub_personal[grep("헤어케어", sub_personal$CLAC2_NM),]
sun <- sub_cosmetic[grep("선케어", sub_cosmetic$CLAC2_NM),]
#install.packages("plyr")
library(plyr)
cleansing <- ddply(cleanser, .(SESS_DT), summarise, BUY = sum(PD_BUY_CT))
suncare <- ddply(sun, .(SESS_DT), summarise, BUY = sum(PD_BUY_CT))
haircare <- ddply(sun, .(SESS_DT), summarise, BUY = sum(PD_BUY_CT))


##일별 엘포인트 클렌징&선&헤어케어 구매건수와 미세먼지 데이터 합하기
air <- air_seoul[,c(1,4,5)]
air_CSH <- data.frame(air,cleansing$BUY,suncare$BUY,haircare$BUY) 


##등분산 검정 & 분산분석 함수
dust_anova_oneway <- function (dust,microdust,z) { #dust:미세먼지데이터, microdust:초미세먼지데이터, z:비교데이터
  z <- as.data.frame(z)
  dustlevel <- cut(dust, breaks=c(0,30,80,150,Inf), labels=c("good","normal","bad","terrible")) #미세먼지 농도
  microdlevel <-cut(microdust, breaks=c(0,15,35,75,Inf), labels=c("good","normal","bad","terrible")) #초미세먼지 농도 
  data1 <- data.frame(dustlevel, z)
  data2 <- data.frame(microdlevel, z)
  #install.packages("car")
  library(car)
  leven1 <- with(data1, leveneTest(z~dustlevel)) #미세먼지
  leven2 <- with(data2, leveneTest(z~microdlevel)) #초미세먼지
  fit1 <- aov(z~dustlevel, data=data1)
  summary1 <- summary(fit1)
  fit2 <- aov(z~microdlevel, data=data2)
  summary2 <- summary(fit2)
  print(leven1)
  print("-------------------------------------------------------------------")
  print(summary1)
  print("-------------------------------------------------------------------")
  print(leven2)
  print("-------------------------------------------------------------------")
  print(summary2)
}


##사후분석함수
#미세먼지
aftertest_dust <- function (dust, z) {
  z <- as.data.frame(z)
  dustlevel <- cut(dust, breaks=c(0,30,80,150,Inf), labels=c("good","normal","bad","terrible"))
  data <- data.frame(dustlevel, z)
  fit <- aov(z~dustlevel, data=data)
  result <- TukeyHSD(fit)
  plot <- plot(result)
  print(result)
  print(plot)
}
#초미세먼지
aftertest_micro <- function (microdust, z) {
  z <- as.data.frame(z)
  microdlevel <- cut(microdust, breaks=c(0,15,35,75,Inf), labels=c("good","normal","bad","terrible"))
  data <- data.frame(microdlevel, z)
  fit <- aov(z~microdlevel, data=data)
  result <- TukeyHSD(fit)
  plot <- plot(result)
  print(result)
  print(plot)
}

##데이터랩 전체달 4-9월 데이터&분석
d_dust_all <- air_datalap[,2]  #미세먼지
d_microdust_all <- air_datalap[,3]  #초미세먼지
d_cleansing_all <-  air_datalap[,4]
d_skincare_all <-  air_datalap[,5]
d_suncare_all <-  air_datalap[,6]
d_haircare_all <- air_datalap[,7]
d_maskpack_all <- air_datalap[,8]

#분산분석
dust_anova_oneway(d_dust_all,d_microdust_all,d_cleansing_all)
dust_anova_oneway(d_dust_all,d_microdust_all,d_skincare_all)
dust_anova_oneway(d_dust_all,d_microdust_all,d_suncare_all)
dust_anova_oneway(d_dust_all,d_microdust_all,d_haircare_all)
dust_anova_oneway(d_dust_all,d_microdust_all,d_maskpack_all)

#사후분석
aftertest_dust(d_dust_all,d_cleansing_all)

aftertest_dust(d_dust_all,d_suncare_all)
aftertest_micro(d_microdust_all,d_suncare_all)

aftertest_dust(d_dust_all,d_haircare_all)
aftertest_micro(d_microdust_all,d_haircare_all)


##엘포인트 전체달 4-9월 데이터&분석
l_dust_all <- air_CSH[,2]  #미세먼지
l_microdust_all <- air_CSH[,3]  #초미세먼지
l_cleansing_all <- air_CSH[,4] #페이셜클렌저 구매
l_suncare_all <- air_CSH[,5]   #선케어 구매 
l_haircare_all <- air_CSH[,6]  #헤어케어 구매

#분산분석
dust_anova_oneway(l_dust_all,l_microdust_all,l_cleansing_all)
dust_anova_oneway(l_dust_all,l_microdust_all,l_suncare_all)
dust_anova_oneway(l_dust_all,l_microdust_all,l_haircare_all)

#사후분석
aftertest_dust(l_dust_all,l_suncare_all)
aftertest_micro(l_microdust_all,l_suncare_all)

aftertest_dust(l_dust_all,l_haircare_all)
aftertest_micro(l_microdust_all,l_haircare_all)
